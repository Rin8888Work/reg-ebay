import fs from "fs";
import path from "path";

// Path to the folder you want to read
const folderPath = "E:\\BACKUP_LD_EBAY";

const run = () => {
  return new Promise((resolve, reject) => {
    fs.readFile("name.txt", "utf8", (err, data) => {
      if (err) {
        reject(err);
        return;
      }

      // Tách dữ liệu thành các dòng
      // Read the contents of the folder
      fs.readdir(folderPath, (err, files) => {
        if (err) {
          console.error("Error reading folder:", err);
          return;
        }

        resolve({
          allBackupFiles: files,
          names: data
            .split("\n")
            .map((i) => i.replace("\r", ""))
            .filter((i) => i !== ""),
        });
      });
    });
  });
};

const { allBackupFiles, names } = await run();

for (let index = 0; index < names.length; index++) {
  const name = names[index];
  const fileBackup = allBackupFiles.find((i) => i.includes(name));
  console.log({ name, fileBackup });
  if (fileBackup) {
    fs.rename(
      path.join(folderPath, fileBackup),
      path.join(folderPath, "BUYER-15-3", fileBackup),
      (err) => {
        if (err) {
          console.error("Error moving file:", err);
          return;
        }

        console.log(`File ${fileBackup} moved successfully.`);
      }
    );
  }
}
